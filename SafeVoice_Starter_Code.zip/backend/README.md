# SafeVoice Backend
Express server for handling SafeVoice APIs.