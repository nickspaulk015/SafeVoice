# Installation
Instructions on setting up SafeVoice locally.