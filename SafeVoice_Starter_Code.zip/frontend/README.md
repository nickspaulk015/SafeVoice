# SafeVoice Frontend
React Native app for reporting and support.